"""
AWS Auto-Tagging Lambda Function Package
Automatically tags AWS resources with creator user ARN
"""

__version__ = "1.0.0"
__author__ = "DevOps Team"

